#!/bin/bash
NAME=$(basename "$0")
if [ "$NAME" = "template_task.sh" ]; then
    echo "я бригадир, сам не работаю"
    exit 1
fi

PIPE=/run/cuckoo.pipe
REPORT="report_${NAME}.log"
log() { echo "$(date '+%F %T') [$$] $*" >> "$REPORT"; }

log "Скрипт запущен"

REPLY=$(mktemp -u /tmp/reply.XXXXXX)
mkfifo "$REPLY" || exit 1
exec 4<>"$REPLY"
echo "$NAME[$$]: how much time do I have?" > "$PIPE"
read -r -t 5 -u 4 N
exec 4<&-
rm -f "$REPLY"

if [[ ! $N =~ ^[0-9]+$ ]]; then
    log "Нет ответа от cuckoo"
    exit 1
fi

sleep "$N"
log "Скрипт завершился, работал $N секунд"
