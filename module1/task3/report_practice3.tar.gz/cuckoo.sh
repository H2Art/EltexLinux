#!/bin/bash
for a in "$@"; do
    case "$a" in
        --pishitesuda=*) PIPE="${a#*=}" ;;
    esac
done
if [ -z "$PIPE" ]; then
    echo "Использование: $0 --pishitesuda=/абсолютный/путь" >&2
    exit 1
fi

LOG=/opt/eltex/cuckoo.log
log() { echo "$(date '+%F %T') $*" >> "$LOG"; }

cleanup() {
    log "Shutdown!"
    rm -f "$PIPE"
    exit 0
}
trap cleanup SIGTERM

mkfifo "$PIPE" || exit 1
log "Startup!"
exec 3<>"$PIPE"

re='^(.+)\[([0-9]+)\]: how much time do I have\?$'
while true; do
    read -r -t 1 -u 3 line || continue
    if [[ $line =~ $re ]]; then
        name="${BASH_REMATCH[1]}"
        pid="${BASH_REMATCH[2]}"
        [ -r "/proc/$pid/comm" ] && name=$(< "/proc/$pid/comm")
        n=$(( RANDOM % 9 + 2 ))
        log "$name[$pid] $n"
        [ -e "/proc/$pid/fd/4" ] && echo "$n" > "/proc/$pid/fd/4"
    fi
done
EOF
