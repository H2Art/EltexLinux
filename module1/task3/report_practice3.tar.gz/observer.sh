#!/bin/bash
cd /opt/eltex || exit 1

while read -r script; do
    [[ -z $script || $script == \#* ]] && continue
    found=0
    for c in /proc/[0-9]*/cmdline; do
        mapfile -d '' -t args 2>/dev/null < "$c" || continue
        for a in "${args[@]}"; do
            [ "$a" = "$script" ] && { found=1; break 2; }
        done
    done
    if [ $found -eq 0 ]; then
        nohup "$script" >/dev/null 2>&1 &
        echo "$(date '+%F %T') перезапущен $script" >> observer.log
    fi
done < observer.conf
